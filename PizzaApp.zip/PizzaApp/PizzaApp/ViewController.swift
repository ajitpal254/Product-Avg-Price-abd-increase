//
//  ViewController.swift
//  PizzaApp
//
//  Created by MacStudent on 2020-03-04.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var small: UIButton!
    @IBOutlet weak var medium: UIButton!
    @IBOutlet weak var large: UIButton!
    
 
    
    @IBOutlet weak var peperoni: UIButton!
    @IBOutlet weak var mushroom: UIButton!
    @IBOutlet weak var onions: UIButton!
    @IBOutlet weak var sausage: UIButton!
    @IBOutlet weak var bacon: UIButton!
    @IBOutlet weak var extracheese: UIButton!
    @IBOutlet weak var blackOlives: UIButton!
    @IBOutlet weak var greenPeppers: UIButton!

    @IBOutlet weak var qty: UITextField!
   
    @IBOutlet weak var billAmount: UILabel!
    @IBAction func orderCalculate(_ sender: Any) {
        var amt : Double = 0
        let quantity = Double(qty.text!)!
        if small.isSelected{
        if(peperoni.isSelected){
            amt = amt+2
        }
         if(mushroom.isSelected){
            amt = amt+2
            
        }
         if(onions.isSelected){
            amt = amt+2
        }
         if(sausage.isSelected){
            amt = amt+2
        }
         if(bacon.isSelected){
            amt = amt+2
        }
         if(extracheese.isSelected){
            amt = amt+2
        }
         if(blackOlives.isSelected){
            amt = amt+2
        }
         if(greenPeppers.isSelected){
            amt = amt+2
        }
            let bill = quantity*((amt + 8.99) - 4.00)
            billAmount.text = "Your Bill is" + String(format: "%.2f",bill)
    }
       else if medium.isSelected{
            if(peperoni.isSelected){
                     amt = amt+2
                 }
                  if(mushroom.isSelected){
                     amt = amt+2
                     
                 }
                  if(onions.isSelected){
                     amt = amt+2
                 }
                  if(sausage.isSelected){
                     amt = amt+2
                 }
                  if(bacon.isSelected){
                     amt = amt+2
                 }
                  if(extracheese.isSelected){
                     amt = amt+2
                 }
                  if(blackOlives.isSelected){
                     amt = amt+2
                 }
                  if(greenPeppers.isSelected){
                     amt = amt+2
                 }
            let bill = quantity*((amt + 12.99) - 4.00)
            billAmount.text = "Your Bill is" + String(format: "%.2f",bill)
            
        }
        else if large.isSelected{
            if(peperoni.isSelected){
                            amt = amt+2
                        }
                         if(mushroom.isSelected){
                            amt = amt+2
                            
                        }
                         if(onions.isSelected){
                            amt = amt+2
                        }
                         if(sausage.isSelected){
                            amt = amt+2
                        }
                         if(bacon.isSelected){
                            amt = amt+2
                        }
                         if(extracheese.isSelected){
                            amt = amt+2
                        }
                         if(blackOlives.isSelected){
                            amt = amt+2
                        }
                         if(greenPeppers.isSelected){
                            amt = amt+2
                        }
                   let bill = quantity*((amt + 14.99) - 4.00)
            billAmount.text = "Your Bill is" + String(format: "%.2f",bill)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    
    }
    @IBAction func largePizza(_ sender: UIButton) {
        if sender.isSelected {
                        sender.isSelected = false
                    } else {
                        sender.isSelected = true
                        medium.isSelected = false
                        small.isSelected = false
                }
    }
    @IBAction func mediumPizza(_ sender: UIButton) {
        if sender.isSelected {
                         sender.isSelected = false
                     } else {
                         sender.isSelected = true
                         small.isSelected = false
                         large.isSelected = false
                 }
    }
    @IBAction func smallPizza(_ sender: UIButton) {
        if sender.isSelected {
                sender.isSelected = false
            } else {
                sender.isSelected = true
                medium.isSelected = false
                large.isSelected = false
        }
    }
   
   
    @IBAction func peperoni(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        } else {
            sender.isSelected = true
        }
    }
    @IBAction func mushrooms(_ sender: UIButton) {
        if sender.isSelected {
                   sender.isSelected = false
               } else {
                   sender.isSelected = true
               }
    }
    @IBAction func onions(_ sender: UIButton) {
        if sender.isSelected {
                   sender.isSelected = false
               } else {
                   sender.isSelected = true
               }
    }
    @IBAction func sausage(_ sender: UIButton) {
        if sender.isSelected {
                   sender.isSelected = false
               } else {
                   sender.isSelected = true
               }
    }
    @IBAction func bacon(_ sender: UIButton) {
        if sender.isSelected {
                   sender.isSelected = false
               } else {
                   sender.isSelected = true
               }
    }
    @IBAction func extracheese(_ sender: UIButton) {
        if sender.isSelected {
                   sender.isSelected = false
               } else {
                   sender.isSelected = true
               }
    }
    @IBAction func blackOlives(_ sender: UIButton) {
        if sender.isSelected {
                   sender.isSelected = false
               } else {
                   sender.isSelected = true
               }
    }
    
    @IBAction func greenPeppers(_ sender: UIButton) {
        if sender.isSelected {
                   sender.isSelected = false
               } else {
                   sender.isSelected = true
               }
    }
    

}
