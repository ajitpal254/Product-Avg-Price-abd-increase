package com.example.tempretureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    // let the user enter a temperatures in celsius or in fahrenhite
// convert from the not empty temperature to the empty one
//if both null show a message says enter the temperature to convert
    EditText celcius, farhenhiet;
    Button calculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        celcius = findViewById(R.id.degreeCel);
        farhenhiet = findViewById(R.id.degreeFar);
        calculate = findViewById(R.id.calc);
        calculate.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (!celcius.getText().toString().equals("")) {
            double celci = Double.parseDouble(celcius.getText().toString());
            double result = ((celci * 1.8) + 32);
            Double celciObj = new Double(result);
            farhenhiet.setText(String.format("%.1f", celciObj));

        }
        else if (!farhenhiet.getText().toString().equals("")) {

            double fahr = Double.parseDouble(farhenhiet.getText().toString());
            double result = (((fahr - 32.0) * 5)/9);
            Double fahrObj = new Double(result);
            celcius.setText(String.format("%.1f", fahrObj));
        }
        if (farhenhiet.getText().toString().equals("") && celcius.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(),"Please enter a value",Toast.LENGTH_LONG).show();
            }

    }
}
