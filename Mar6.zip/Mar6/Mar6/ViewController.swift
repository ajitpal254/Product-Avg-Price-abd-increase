//
//  ViewController.swift
//  Mar6
//
//  Created by MacStudent on 2020-03-06.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import UIKit
let pickerData = ["McLaren","Bugaati","Jaguar","Mazda","BMW"]
let dailyPrice = [65,70,60,50,75]
class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }

    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var lessEighteen: UIButton!
    @IBOutlet weak var eighteenPlus: UIButton!
    @IBOutlet weak var sixtyFivePlus: UIButton!
    @IBOutlet weak var nav: UIButton!
    @IBOutlet weak var chldSeat: UIButton!
    @IBOutlet weak var Unlmtd: UIButton!
    @IBOutlet weak var cars: UIImageView!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var dPrice: UITextField!
    
    @IBOutlet weak var days: UITextField!
    @IBOutlet weak var res: UILabel!
    
    @IBAction func claculation(_ sender: Any) {
        var amt: Double = 0
        let n1 = Double(days.text!)!
        let n2 = Double(dPrice.text!)!
        if lessEighteen.isSelected{
            if nav.isSelected{
                amt = amt + 7
            }
            if chldSeat.isSelected{
                amt = amt + 6
            }
            if Unlmtd.isSelected{
                amt = amt * 1.5
        }
            let result = (((5.0 * n1) + amt + (n1 * n2)) * 0.13) + (5.0 + amt + (n1 * n2))
            res.text = "Amount To be Paid:" + String(format: "%.2f",result)
        }
        if eighteenPlus.isSelected{
            if nav.isSelected{
                    amt = amt + 7
                }
                if chldSeat.isSelected{
                    amt = amt + 6
                }
                if Unlmtd.isSelected{
                    amt = amt * 1.5
            }
            let result = ((amt + (n1 * n2) ) * 0.13) + (amt + (n1 * n2) )
            res.text = "Amount To be Paid:" + String(format: "%.2f",result)
        }
        if sixtyFivePlus.isSelected{
            if nav.isSelected{
                               amt = amt + 7
                           }
                           if chldSeat.isSelected{
                               amt = amt + 6
                           }
                           if Unlmtd.isSelected{
                               amt = amt * 1.5
                       }
            let result = (((amt + (n1 * n2)) * 1.10) + ((amt + (n1 * n2))) * 0.13) + (amt + (n1 * n2))
            res.text = "Amount To be Paid:" + String(format: "%.2f",result)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        // Do any additional setup after loading the view.
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        cars.image = UIImage(named:pickerData[row])
        price.text = "Daily Price for selected Car:"
        dPrice.text = String(dailyPrice[row])
    }
    @IBAction func firstOption(_ sender: UIButton) {if sender.isSelected{
        sender.isSelected = false
        }
    else{
        sender.isSelected = true
        eighteenPlus.isSelected = false
        sixtyFivePlus.isSelected = false
        }
    }
    @IBAction func secondOption(_ sender: UIButton) {if sender.isSelected{
            sender.isSelected = false
            }
        else{
            sender.isSelected = true
            lessEighteen.isSelected = false
        sixtyFivePlus.isSelected = false
        }
    }
    @IBAction func thirdOption(_ sender: UIButton) {if sender.isSelected{
            sender.isSelected = false
            }
        else{
            sender.isSelected = true
        lessEighteen.isSelected = false
        eighteenPlus.isSelected = false
        }
    }
    @IBAction func navigatir(_ sender: UIButton) {if sender.isSelected{
        sender.isSelected = false
        }
    else{
        sender.isSelected = true
        }
    }
    @IBAction func childSeat(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            }
        else{
            sender.isSelected = true
            }
    }
    @IBAction func Milage(_ sender: UIButton) {if sender.isSelected{
            sender.isSelected = false
            }
        else{
            sender.isSelected = true
            }
    }

}

